import Hikes from './hikes.js';

const myHike = new Hikes('hikeListId');

//myHike.showHikeList();

window.addEventListener("load", () => {
    myHikes.showHikeList();
  });